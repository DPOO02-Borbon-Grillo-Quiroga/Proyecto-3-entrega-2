package modelo;



public class PaqueteTrabajo {
	
	private String nombre;
	private String descripcion;
	private Tarea[] tareas;

	// constructor
	
	public PaqueteTrabajo(String pNombre, String pDescripcion, Tarea[] pTareas)
	{
		nombre = pNombre;
		descripcion = pDescripcion;
		tareas = pTareas;
	}
	
	// Metodos
	
	public String getNombrePaquete()
	{
		return nombre;
	}
	
	public Tarea[] getListaTareas()
	{
		return this.tareas;
	}
	public String getDescipPac()
	{
		return this.descripcion;
	}
	
	public String[] getTareas()
	{
		int tamano = tareas.length;
		int i = 0;
		String[] retorno = new String[tamano]; 
		
		while (i != tamano-1) {
			String nombreTarea = tareas[i].getNombreTarea();
			retorno[i] = nombreTarea;
			i = i+1;
		}
		return retorno;
	}

	public void setTareaNueva(Tarea nueva)
	{
		Tarea[] lista = this.getListaTareas();
		int tamanio = lista.length;
		tamanio = tamanio - 1;
		this.tareas[tamanio] = nueva;
	}
}
