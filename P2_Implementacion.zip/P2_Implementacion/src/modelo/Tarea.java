package modelo;

import java.util.ArrayList;

public class Tarea {
	
	private String nombre; 
	private String descripcion;
	private int tiempoEstimado;
	private Participante[] responsables;
	
	public Tarea(String pNombre, String pDescripcion, int pTiempoEstimado,Participante[] pResponsables)
	{
		nombre = pNombre;
		descripcion = pDescripcion;
		tiempoEstimado = pTiempoEstimado;
		responsables = pResponsables;
	}
	
	public String getNombreTarea()
	{
	return nombre;
	}
	
	public Participante[] getListaParticipantes()
	{
		return this.responsables;
		
	}
	
	public String getDescripcion()
	{
		return this.descripcion;
		
	}
	public int getTiempoEstimado()
	{
		return this.tiempoEstimado;
	}
	public String[] getParticipantes()
	{
		int tamano = responsables.length;
		int i = 0;
		String[] retorno = new String[tamano];
		while (i != tamano-1)
		{
			String nombrePersona = responsables[i].getNombre();
			retorno[i] = nombrePersona;
			i = i+1;
		
		}
		return retorno;
	}
	public void setParticipanteNuevo(Participante nueva)
	{
		Participante[] lista = this.responsables;
		int tamanio = lista.length;
		tamanio = tamanio - 1;
		this.responsables[tamanio] = nueva;
	}
}
